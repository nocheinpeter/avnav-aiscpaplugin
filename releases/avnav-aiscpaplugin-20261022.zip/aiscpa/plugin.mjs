// AVNAV AIS CPA on map display widget

/**
 * # Copyright (c) 2026 Peter Stur
 #
 #  Permission is hereby granted, free of charge, to any person obtaining a
 #  copy of this software and associated documentation files (the "Software"),
 #  to deal in the Software without restriction, including without limitation
 #  the rights to use, copy, modify, merge, publish, distribute, sublicense,
 #  and/or sell copies of the Software, and to permit persons to whom the
 #  Software is furnished to do so, subject to the following conditions:
 #
 #  The above copyright notice and this permission notice shall be included
 #  in all copies or substantial portions of the Software.
 #
 #  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 #  OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 #  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 #  THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHERtime
 #  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 #  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 #  DEALINGS IN THE SOFTWARE.
 #
 */
//import NavCompute from '../../../nav/navcompute';
//import navobjects from '../../../nav/navobjects';
//import LatLonSpherical from 'geodesy/latlon-spherical';
import LatLon from 'https://cdn.jsdelivr.net/npm/geodesy@2/latlon-spherical.js'; // browser

export default async (api) => {

    var AisCpaWidget = {
        name: "AisCpaWidget",
        type: "map",
        // Fordere einfach alles an, was dich interessiert
        storeKeys: {
            // see https://github.com/wellenvogel/avnav/blob/master/viewer/util/keys.ts
            aisList: 'nav.ais.list',
            aisUpdateCount: 'nav.ais.updateCount',
            position: 'nav.gps.position',
            course: 'nav.gps.course',
            speed: 'nav.gps.speed'
        },
        renderCanvas: function (canvas, props) {
             console.log("AisCpaWidget::renderCanvas() props = ", props);
            // quit if no data
            if (!props.position || !props.position.lat || !props.position.lon
                || !props.course || !props.speed) {
                console.log("AisCpaWidget::renderCanvas() no data ", props);
                return;
            }

            var ctx = canvas.getContext('2d');
            ctx.save();
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            // Gibt den gesamten Store-Inhalt bei jedem Update in der Browser-Konsole aus!
            //console.log("AisCpaWidget::renderCanvas() aisList = ", props.aisList);
            console.log("AisCpaWidget::renderCanvas() aisUpdateCount = ", props.aisUpdateCount);
            //console.log("Komplette AIS-Daten:", avnav.api.getData('ais'));
            //console.log("Props als JSON:", JSON.stringify(allData, null, 2));
            for (const aisidx in props.aisList) {
                const ais = props.aisList[aisidx];
                if (ais.warning) {
                    console.log("AisCpaWidget::renderCanvas() ais warning for MMSI " + ais.mmsi + ", name " + ais.received.shipname);
                    console.log("AisCpaWidget::renderCanvas() ais = ", ais);

                    let LatLon  =api.LatLon();
                    let aP1 = new LatLon(ais.estimated.lat, ais.estimated.lon);
                    let aP2 = aP1.destinationPoint(ais.received.speed * ais.cpadata.tcpa, ais.received.course);
                    var aTargetCPAXY = this.lonLatToPixel(aP2.lon, aP2.lat);
                    var aTargetCPAX = aTargetCPAXY[0];
                    var aTargetCPAY = aTargetCPAXY[1];

                    let aP3 = new LatLon(props.position.lat, props.position.lon);
                    let aP4 = aP3.destinationPoint(props.speed * ais.cpadata.tcpa, props.course);
                    var aOwnCPAXY = this.lonLatToPixel(aP4.lon, aP4.lat);
                    var aOwnCPAX = aOwnCPAXY[0];
                    var aOwnCPAY = aOwnCPAXY[1];
                  

                    // Zeichne Vektor am Boot
                    ctx.beginPath();
                    ctx.strokeStyle = 'cyan';
                    ctx.lineWidth = 3;

                    ctx.moveTo(aOwnCPAX, aOwnCPAY);
                    ctx.lineTo(aTargetCPAX, aTargetCPAY);
                    ctx.stroke();

                    // Kleine Pfeilspitze oder Kreis am Ende
                    ctx.strokeStyle = "black";
                    ctx.fillStyle = 'yellow';
                    ctx.beginPath();
                    ctx.arc(aOwnCPAX, aOwnCPAY, 6, 0, 2 * Math.PI);
                    ctx.fill();
                    ctx.stroke();

                    ctx.beginPath();
                    ctx.arc(aTargetCPAX, aTargetCPAY, 6, 0, 2 * Math.PI);
                    ctx.fill();
                    ctx.stroke();
                }
            }

            ctx.restore();
            console.log("AisCpaWidget::renderCanvas() fini");
        }
    }


    api.registerWidget(AisCpaWidget);

    console.log("aiscpa plugin.mjs loaded")
    console.log("name", api.getPluginName());
    console.log("baseUrl", api.getBaseUrl());
    const cfg = await api.getConfig();
    console.log("plugin config", cfg);
    return () => {
        console.log("cleanup called for aiscpa plugin.mjs");
    }
};